

public class Node {

	int key;
	String name;

	Node left;
	Node right;

	//constructor
	Node(int key, String name) {

		this.key = key;
		this.name = name;

	}

	//print
	public String toString() {

		return name + " with the key " + key;

	}
}
