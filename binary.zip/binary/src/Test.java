

public class Test {

	public static void main(String[] args) {
		
		BinaryTree Tree = new BinaryTree();

		Tree.insert(50, "CEO");

		Tree.insert(25, "Vice President");

		Tree.insert(15, "Project Manager");

		Tree.insert(30, "Assistant");

		Tree.insert(75, "Production Manager");

		Tree.insert(85, "Salesman");
		
		//Tree.remove(75);

		Tree.inorderTraverse(Tree.root);

		//Tree.preorderTraverse(Tree.root);

		//Tree.postorderTraverse(Tree.root);


		System.out.println("\nNode with the key 75");

		System.out.println(Tree.search(75));

	}

}
